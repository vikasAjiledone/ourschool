const PreLoader = () => {
  return (
    <div id="preload" className="preload">
      <div className="preload-logo"></div>
    </div>
  );
};
export default PreLoader;
